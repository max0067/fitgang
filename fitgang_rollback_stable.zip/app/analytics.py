"""
Module de tracking et analytics pour FitGang - VERSION DÉSACTIVÉE
Ce fichier existe pour éviter les erreurs d'import mais ne fait rien
"""

def get_visitor_stats():
    """
    Retourne des statistiques vides
    L'analytics est désactivé pour le moment
    """
    return {
        'visitors_live': 0,
        'pageviews_live': 0,
        'visitors_today': 0,
        'pageviews_today': 0,
        'visitors_yesterday': 0,
        'pageviews_yesterday': 0,
        'visitors_week': 0,
        'pageviews_week': 0,
        'visitors_month': 0,
        'pageviews_month': 0,
        'visitors_total': 0,
        'pageviews_total': 0,
        'top_pages_today': [],
        'top_referers_today': [],
        'visitors_trend': []
    }


def check_visits_table_exists():
    """Retourne False - la table n'existe pas"""
    return False


def track_visit():
    """Ne fait rien - tracking désactivé"""
    pass
